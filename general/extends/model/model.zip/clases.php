<?php


include("general/extends/model/clases_credito.php");
include("general/extends/model/clases_cuotas.php");

include("general/extends/model/clases_eventos.php");

include("general/extends/model/calculos_creditos.php");
include("general/extends/model/calculos_cuotas.php");

include("general/extends/model/class_db.php");
